
/* =====================================
   MA​​KAZIWE MTSWENI - PORTFOLIO
   JavaScript functionality
===================================== */

// 1. AUTOMATICALLY DISPLAY THE CURRENT YEAR

const yearElement = document.getElementById("currentYear");

if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
}


// 2. MOBILE NAVIGATION MENU

const menuButton = document.querySelector(".menu-toggle");
const navigationLinks = document.querySelector(".nav-links");

if (menuButton && navigationLinks) {
    menuButton.addEventListener("click", function () {
        navigationLinks.classList.toggle("open");

        const isOpen = navigationLinks.classList.contains("open");

        menuButton.setAttribute("aria-expanded", isOpen);
        menuButton.textContent = isOpen ? "✕" : "☰";
    });

    // Close the menu after selecting a page.

    const links = navigationLinks.querySelectorAll("a");

    links.forEach(function (link) {
        link.addEventListener("click", function () {
            navigationLinks.classList.remove("open");
            menuButton.setAttribute("aria-expanded", "false");
            menuButton.textContent = "☰";
        });
    });
}


// 3. CONTACT FORM VALIDATION AND EMAIL DRAFT

const contactForm = document.getElementById("portfolioContactForm");

if (contactForm) {
    contactForm.addEventListener("submit", function (event) {

        event.preventDefault();

        const name = document.getElementById("visitorName").value.trim();
        const email = document.getElementById("visitorEmail").value.trim();
        const subject = document.getElementById("visitorSubject").value.trim();
        const message = document.getElementById("visitorMessage").value.trim();

        const status = document.getElementById("formStatus");

        // Check that all fields contain information.

        if (!name || !email || !subject || !message) {
            status.textContent = "Please complete all the fields.";
            return;
        }

        // Prepare an email message.

        const recipient = "mtshwenimakaziwe1@gmail.com";

        const emailSubject = encodeURIComponent(subject);

        const emailBody = encodeURIComponent(
            "Name: " + name + "\n" +
            "Email: " + email + "\n\n" +
            "Message:\n" + message
        );

        const emailLink =
            "mailto:" + recipient +
            "?subject=" + emailSubject +
            "&body=" + emailBody;

        status.textContent =
            "Opening your email application. Please send the prepared message there.";

        window.location.href = emailLink;
    });
}
